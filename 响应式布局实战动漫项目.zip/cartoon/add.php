<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>index</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="public/bs/css/bootstrap.min.css">
	<link rel="stylesheet" href="public/css/index.css">
	<script src="public/js/jquery.js"></script>
	<script src="public/bs/js/bootstrap.min.js"></script>
	<script src="public/kd/kindeditor-min.js"></script>
</head>
	<div class="container">
		<?php 
			include 'header.php';
		?>	
		<div class="nav"></div>
		<div class="nav"></div>
		<div class="nav"></div>
		<div class="content">
			<form action="insert.php" method='post' enctype='multipart/form-data'>
				<div class="form-group">
					<label for="">发布者:</label>	
					<input type="text" name='username' class="form-control" placeholder='username'>
				</div>
				<div class="form-group">
					<label for="">动漫名称:</label>	
					<input type="text" name='title' class="form-control" placeholder='cartoon name'>
				</div>
				<div class="form-group"  >
					<label for="">动漫图片:</label>	
					<input type="file" name='img' placeholder='cartoon img'>
				</div>
				<div class="form-group">
					<label for="">动漫简介:</label>	
					<textarea  id='cartoon-info' rows='10' name="content" class='form-control'></textarea>
				</div>
				<div class="form-group">
					<input type="submit" value="Ok" class='btn btn-primary'>	
					<input type="reset" value="Cancel" class='btn btn-danger'>	
				</div>
			</form>	
		</div>
		<?php 
			include 'footer.php';
		?>	
	</div>
</body>
<script>
var editor;
KindEditor.ready(function(K){
	editor=K.create('#cartoon-info',{
		items : [
		'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold', 'italic', 'underline',
		'removeformat', '|', 'justifyleft', 'justifycenter', 'justifyright', 'insertorderedlist',
		'insertunorderedlist', '|', 'emoticons', 'image', 'link']
	});
});
</script>
</html>