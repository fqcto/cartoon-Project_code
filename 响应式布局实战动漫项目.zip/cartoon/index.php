<?php 
include 'public/common/config.php';
$sqlMess="select * from message order by id desc";

$rstMess=mysql_query($sqlMess);
?>

<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>index</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="public/bs/css/bootstrap.css">
	<link rel="stylesheet" href="public/css/index.css">
	<script src="public/js/jquery.js"></script>
	<script src="public/bs/js/bootstrap.min.js"></script>
	<script src='public/js/index.js'></script>
</head>
<body>
	<div class="container">
		<?php 
			include 'header.php';
		?>

		<div class="slider">

			<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
			  <!-- Indicators -->
			  <ol class="carousel-indicators">
			    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
			    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
			    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
			    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
			    <li data-target="#carousel-example-generic" data-slide-to="4"></li>
			  </ol>

			  <!-- Wrapper for slides -->
			  <div class="carousel-inner">
			    <div class="item active">
			      <img src="public/images/a.jpg" alt="...">
			    </div>
			    <div class="item">
			      <img src="public/images/b.jpg" alt="...">
			    </div>
			    <div class="item">
			      <img src="public/images/c.jpg" alt="...">
			    </div>
			    <div class="item">
			      <img src="public/images/d.jpg" alt="...">
			    </div>
			    <div class="item">
			      <img src="public/images/e.jpg" alt="...">
			    </div>
			  </div>

			  <!-- Controls -->
			  <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
			    <span class="glyphicon glyphicon-chevron-left"></span>
			  </a>
			  <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
			    <span class="glyphicon glyphicon-chevron-right"></span>
			  </a>
			</div>


		</div>

		<div class="content">
			<?php 
			while($rowMess=mysql_fetch_assoc($rstMess)){
			?>

			<div class="panel panel-primary">
				<div class="panel-heading">
					<div class="panel-title">
					<img src="public/images/headimg.jpg" class="img-circle">
					<span>&nbsp;&nbsp;&nbsp;<?php echo $rowMess['title'] ?></span>
					</div>
				</div>
				<div class="panel-body">
					<img src="public/images/<?php echo $rowMess['img']?>"  class="img-responsive img1">
					<p >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rowMess['content']?>	</p>
				</div>
				<div class="panel-footer">
					<span><b class='label label-primary'>发布者:</b> <?php echo $rowMess['username']?></span>
					<span class='time'><b class='label label-danger'>发布时间:</b> <?php echo date('Y-m-d H:i:s',$rowMess['time'])?></span>
				</div>
			</div>	

			<?php
			}
			?>
		</div>

		<?php 
			include 'footer.php';
		?>	
	</div>	
</body>
</html>