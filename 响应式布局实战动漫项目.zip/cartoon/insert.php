<?php 
include 'public/common/config.php';

$username=$_POST['username'];
$title=$_POST['title'];
$content=$_POST['content'];
$time=time();


//图片上传
$src=$_FILES['img']['tmp_name'];

$name=$_FILES['img']['name'];

$ext=array_pop(explode('.',$name));

$dst='public/images/'.time().mt_rand().'.'.$ext;

if(move_uploaded_file($src,$dst)){

	$img=basename($dst);
	
	$sqlMess="insert into message(username,title,content,time,img) values('{$username}','{$title}','{$content}','{$time}','{$img}')";
	if(mysql_query($sqlMess)){
		echo '<script>location="index.php"</script>';
	}
}

?>