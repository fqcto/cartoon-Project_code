<div class="footer">
	<ul class="footer-left">
		<li><span><a href="https://www.fangquan.net.cn" class="link">www.fangquan.net.cn</a></span></li>
	</ul>

	<ul class="footer-right">
		<li><span>不断学习,只为了更好的服务社会!</span></li>
	</ul>
</div>