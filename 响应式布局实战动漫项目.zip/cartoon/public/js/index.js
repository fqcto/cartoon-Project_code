$(function(){
	$('.menu').hover(
		function(){
			$(this).addClass('active');
			$('.menu').not($(this)).removeClass('active');
		});
	$('.panel-body img').add('.logo').addClass('img-responsive');
	$('.carousel').carousel({
		interval:2000
	})

});